Input:
first line indicates size of first array
second line indicates size of second array
third line indicates first array elements seperated with a comma
fourt line indicates second array elements seperated with a comma

output:
resulted array elements seperated with comma
